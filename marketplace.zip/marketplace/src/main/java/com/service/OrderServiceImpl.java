package com.service;

import com.entity.Order;
import com.entity.dto.OrderRequest;
import com.exceptions.OrderDuplicateException;
import com.repository.OrderRepository;
import jakarta.persistence.Access;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class OrderServiceImpl implements OrderService{

    @Autowired
    private OrderRepository orderRepository;

    public List<Order> getOrders(){
        return orderRepository.findAll();
    }

    public Optional<Order> getOrderById(UUID orderId){
        return orderRepository.findById(orderId);
    }

    public Order createOrder(OrderRequest orderRequest){

    }

    public Order updateOrder(OrderRequest orderRequest){

    }

    public Order deleteOrder(UUID orderId){

    }


}
