package com.entity;

public enum Role {
    USER,
    ADMIN
}
